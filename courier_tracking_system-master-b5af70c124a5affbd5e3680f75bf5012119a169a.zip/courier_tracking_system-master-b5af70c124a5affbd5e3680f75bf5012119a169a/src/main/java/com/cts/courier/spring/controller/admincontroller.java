package com.cts.courier.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.courier.spring.model.Package;
import com.cts.courier.spring.model.admin;
import com.cts.courier.spring.model.customer;
import com.cts.courier.spring.service.adminservice;


@Controller
@RequestMapping("/admin")
public class admincontroller {
	
	
	@Autowired
	adminservice adminService;
	@GetMapping("/list")
	public String  listCustomer(Model theModel)
	{
		List<admin> theAdmin=adminService.getCustomers();
		theModel.addAttribute("admin", theAdmin);
		return "staff_details";
		//return "demo";
	}
	
	@GetMapping("/StaffRegistration")
	public String showFormForAdd(Model theModel)
	{
		admin theAdmin=new admin();
		theModel.addAttribute("admin", theAdmin);
		return "StaffRegistration";
	}
	
	
	@GetMapping("/StaffModify")
	public String showFormForAdd2(@RequestParam("id") int theId,Model theModel)
	{
		admin theStaff=adminService.getCustomer(theId);
	    theModel.addAttribute("admin", theStaff);
		return "staff_modify";
	}
	
	@GetMapping("/AdminRegistration")
	public String showFormForAdd1(Model theModel)
	{
		admin theAdmin=new admin();
		theModel.addAttribute("admin", theAdmin);
		return "AdminRegistration";
	}
	
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("admin") admin theAdmin)
	{
		adminService.saveCustomer(theAdmin);
		return "staff_details";
	}
	
	@GetMapping("/updateStaff")
	public String showFormForUpdate(@ModelAttribute("admin") admin theAdmin){
		   adminService.saveCustomer(theAdmin);
	       return"redirect:/admin/list";
	}

	
	
	@PostMapping("/saveCustomer1")
	public String saveCustomer1(@ModelAttribute("admin") admin theAdmin)
	{
		adminService.saveCustomer(theAdmin);
		return "Login";
	}
	
	
	@GetMapping("/customerlogin")
	public String loginMethod(@RequestParam("username") String user, @RequestParam("password") String pass,@RequestParam("type") String type,Model theModel) {
		
		if(type.equals("Admin/Staff")) {
			
			admin theAdmin=adminService.verify(user,pass);
			theModel.addAttribute("admin", theAdmin);
			return "admin_home";
		}
		
		else {
			return "redirect:/customer/customerlogin";
		}
	
	}
	
	
	@GetMapping("/showRules")
	public String showRules()
	{
		return "admin_rules_view";
	}
	
	@GetMapping("/showRules2")
	public String showRules2()
	{
		return "admin_rules_modify";
	}
	
	@GetMapping("/showStaffRules")
	public String showRules1()
	{
		return "staff_rules";
	}
	
	
}
