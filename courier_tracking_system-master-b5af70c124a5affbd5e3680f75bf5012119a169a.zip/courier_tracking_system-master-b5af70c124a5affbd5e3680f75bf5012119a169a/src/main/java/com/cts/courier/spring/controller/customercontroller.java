package com.cts.courier.spring.controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.courier.spring.model.Package;
import com.cts.courier.spring.model.admin;
import com.cts.courier.spring.model.customer;
import com.cts.courier.spring.service.adminservice;
import com.cts.courier.spring.service.customerservice;
import com.cts.courier.spring.service.packageservice;

@Controller
@RequestMapping("/customer")
public class customercontroller {
	
	static String user="";
	static String pass="";
	static String type="";
	
	@Autowired
	customerservice customerService;
	
	@Autowired
	adminservice adminService;
	
	
	@Autowired 
	packageservice packageService;
	
	@GetMapping("/list")
	public String  listCustomer(Model theModel)
	{
		List<customer> theCustomers=customerService.getCustomers();
		theModel.addAttribute("customer", theCustomers);
		return "list-customers";
		//return "demo";
	}
	
	@GetMapping("/UserRegistration")
	public String showFormForAdd(Model theModel)
	{
		customer theCustomer=new customer();
		theModel.addAttribute("customer", theCustomer);
		return "UserRegistration";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") customer theCustomer)
	{
		customerService.saveCustomer(theCustomer);
		return "Login";
	}
	
	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("customerId") int theId,Model theModel)
	{
		customer theCustomer=customerService.getCustomer(theId);
		theModel.addAttribute("customer", theCustomer);
		return "customer-form";
	}
	
	
	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("customerId") int theId)
	{
		customerService.deleteCustomer(theId);
		return "redirect:/customer/list";
	}
	
	@GetMapping("/customerlogin")
	public String loginMethod(@RequestParam("username") String user, @RequestParam("password") String pass,@RequestParam("type") String type,Model theModel) {
		
		
		
		if(type.equals("User")) {
			
			customer theCustomer=customerService.verify(user,pass);
			theModel.addAttribute("customer", theCustomer);
			return "user_home";
		}
		
		else {
			
				admin theAdmin=adminService.verify(user,pass);
				String lt=theAdmin.getLogin_type();
				theModel.addAttribute("admin", theAdmin);
				
				if(lt.equals("A")) {return "admin_home";}
				else {return "staff_home";}
				
		}
		
		
		
		
	}
	
	
	@GetMapping("/show")
	public String showFormForAdd1(Model theModel)
	{
		customer theCustomer=new customer();
		theModel.addAttribute("customer", theCustomer);
		return "Login";
	}
	
	
	@GetMapping("/userPackages")
	public String  listCustomer2(@RequestParam("customerId") String customerId,Model theModel)
	{
		System.out.println("in list");
		List<Package> thePackage=packageService.getPackageByUserId(customerId);
		theModel.addAttribute("Package", thePackage);
		return "UserPackages";
		
	}
	
	@GetMapping("/checkStatus")
	public String checkStatus(@RequestParam("id") int id,Model theModel) {
		Package thePackage=packageService.getCustomer(id);
		theModel.addAttribute("Package", thePackage);
		return "Package_Details";
	}
	
	
	@GetMapping("/findPackage")
	public String showPackages()
	{
		return "find_package";
	}
	
	
}
