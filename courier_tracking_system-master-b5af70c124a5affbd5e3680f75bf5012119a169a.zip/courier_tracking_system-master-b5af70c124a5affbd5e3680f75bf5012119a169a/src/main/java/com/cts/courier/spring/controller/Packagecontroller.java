package com.cts.courier.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.courier.spring.model.Package;
import com.cts.courier.spring.model.customer;
import com.cts.courier.spring.service.packageservice;

@Controller
@RequestMapping("/Package")
public class Packagecontroller {

	@Autowired
	packageservice packageService;
	@GetMapping("/list")
	public String  listCustomer(Model theModel)
	{
		System.out.println("in list");
		List<Package> thePackage=packageService.getCustomers();
		theModel.addAttribute("Package", thePackage);
		return "Admin_package_details";
		//return "demo";
	}
	
	
	@GetMapping("/list1")
	public String  listCustomer1(Model theModel)
	{
		System.out.println("in list");
		List<Package> thePackage=packageService.getCustomers();
		theModel.addAttribute("Package", thePackage);
		return "staff_package_details";
		//return "demo";
	}
	
	@GetMapping("/StaffPackageRegistration")
	public String showFormForAdd(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "StaffPackageRegistration";
	}
	
	@GetMapping("/AdminPackageRegistration")
	public String showFormForAdd2(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "Admin_Package_Registration";
	}
	
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("Package") Package thePackage)
	{
		System.out.println("in savelist");
		packageService.saveCustomer(thePackage);
		return "redirect:/Package/list";
	}
	

	@PostMapping("/saveCustomer1")
	public String saveCustomer1(@ModelAttribute("Package") Package thePackage)
	{
		System.out.println("in savelist");
		packageService.saveCustomer(thePackage);
		return "redirect:/Package/list1";
	}
	
	
	@GetMapping("/updateCurrentLocation")
	public String updateCurrent(@RequestParam("consignmentId") int theId,@RequestParam("date") String date,@RequestParam("current_location") String current_location,Model theModel)
	{
		
		
		Package thePackage=packageService.getCustomer(theId);
		theModel.addAttribute("Package", thePackage);
		packageService.updateCurrentLocation(theId,date,current_location);
		
		return "redirect:/Package/list1";
	}
	
	
	@GetMapping("/updateCurrentLocation1")
	public String updateCurrent1(@RequestParam("consignmentId") int theId,@RequestParam("date") String date,@RequestParam("current_location") String current_location,Model theModel)
	{
		
		
		Package thePackage=packageService.getCustomer(theId);
		theModel.addAttribute("Package", thePackage);
		packageService.updateCurrentLocation(theId,date,current_location);
		
		return "redirect:/Package/list";
	}
	
	
	@GetMapping("/updateStatus")
	public String updateCurrent2(@RequestParam("consignmentId") int theId,@RequestParam("packagestatus") String packagestatus,Model theModel)
	{
		
		
		Package thePackage=packageService.getCustomer(theId);
		theModel.addAttribute("Package", thePackage);
		packageService.updateDeliveryStatus(theId,packagestatus);
		return "redirect:/Package/list1";
		
	}
	
	@GetMapping("/updateStatus1")
	public String updateCurrent3(@RequestParam("consignmentId") int theId,@RequestParam("packagestatus") String packagestatus,Model theModel)
	{
		
		
		Package thePackage=packageService.getCustomer(theId);
		theModel.addAttribute("Package", thePackage);
		packageService.updateDeliveryStatus(theId,packagestatus);
		return "redirect:/Package/list";
		
	}
	
	
	
	@GetMapping("/Staffshow")
	public String showFormForAdd1(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "staff_update_package_location";
	}
	
	
	@GetMapping("/Adminshow")
	public String showFormForAdd3(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "admin_update_package_location";
	}
	
	@GetMapping("/Staffshow2")
	public String showFormForStatusUpdate(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "staff_update_delivery_status";
	}
	
	
	@GetMapping("/Adminshow2")
	public String showFormForStatusUpdate1(Model theModel)
	{
		Package thePackage=new Package();
		theModel.addAttribute("Package", thePackage);
		return "admin_update_delivery_status";
	}
	
}
