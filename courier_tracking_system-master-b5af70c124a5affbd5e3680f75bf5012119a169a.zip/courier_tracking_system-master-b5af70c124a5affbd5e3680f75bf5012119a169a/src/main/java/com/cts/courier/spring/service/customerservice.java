package com.cts.courier.spring.service;

import java.util.List;

import com.cts.courier.spring.model.customer;

public interface customerservice {
	public List<customer> getCustomers();
	public void saveCustomer(customer theCustomer);
	public customer getCustomer(int theId);
	public void deleteCustomer(int theId);
	public customer verify(String username,String pass);
}
