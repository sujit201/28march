package com.cts.courier.spring.dao;

import java.util.List;

import com.cts.courier.spring.model.admin;
import com.cts.courier.spring.model.customer;

public interface adminDAO {

	public List<admin> getCustomers();
	public void saveCustomer(admin theAdmin);
	public admin getCustomer(int theId);
	public admin verify(String username,String pass);
}
