package com.cts.courier.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.courier.spring.dao.adminDAO;
import com.cts.courier.spring.dao.customerDAO;
import com.cts.courier.spring.model.admin;
import com.cts.courier.spring.model.customer;

@Service("adminservice")
public class adminServiceImpl implements adminservice {

	@Autowired
    adminDAO c;
    @Transactional
    public List<admin> getCustomers() {
           // TODO Auto-generated method stub
           return c.getCustomers();
    }
    @Transactional
    public void saveCustomer(admin theAdmin) {
           // TODO Auto-generated method stub
           c.saveCustomer(theAdmin);
    }
    @Transactional
    public admin getCustomer(int theId) {
           // TODO Auto-generated method stub
           return c.getCustomer(theId);
    }
    
    @Transactional
	public admin verify(String username, String pass) {
		// TODO Auto-generated method stub
		return c.verify(username, pass);
	}
   }
