package com.cts.courier.spring.service;

import java.util.List;

import com.cts.courier.spring.model.Package;

public interface packageservice {

	public List<Package> getCustomers();
	public void saveCustomer(Package thePackage);
	public Package getCustomer(int theId);
	public void updateCurrentLocation(int consignmentId,String date,String current_location) ;
	public Package getPackage(String ConsignmnetId);
	public List<Package> getPackageByUserId(String cutomerId);
	public void updateDeliveryStatus(int consignmentId,String status);
}
