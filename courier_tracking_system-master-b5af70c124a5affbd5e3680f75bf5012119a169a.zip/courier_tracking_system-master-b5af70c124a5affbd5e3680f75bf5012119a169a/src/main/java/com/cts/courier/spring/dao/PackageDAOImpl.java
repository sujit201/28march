package com.cts.courier.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.courier.spring.model.Package;
import com.cts.courier.spring.model.customer;

@Repository("PackageDAO")
public class PackageDAOImpl implements packageDAO {
	
	/*@PersistenceUnit
	public EntityManagerFactory emf = Persistence.createEntityManagerFactory("WebApplicationSecurityPU");
	public EntityManager em = emf.createEntityManager();*/
	
	
	@Autowired
	SessionFactory sessionFactory;
	
	public List<Package> getCustomers() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<Package> cq=cb.createQuery(Package.class);
		Root<Package> root=cq.from(Package.class);
		cq.select(root);
		Query query=session.createQuery(cq);
		return query.getResultList();
	}
	
	@Transactional
	public void saveCustomer(Package thePackage) {
		// TODO Auto-generated method stub
		Session currentSession=sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(thePackage);
	}

	public Package getCustomer(int theId) {
		Session currentSession=sessionFactory.getCurrentSession();
		Package thePackage=currentSession.get(Package.class, theId);
		return thePackage;
	}

	@Transactional
	public void updateCurrentLocation(int consignmentId,String date,String current_location) {
		
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<Package> cq=cb.createCriteriaUpdate(Package.class);
		
		Root<Package> e = cq.from(Package.class);
		
		cq.set("current_location", current_location);
		cq.set("date",date);
		cq.where(cb.equal(e.get("id"), consignmentId));
		
		
		TypedQuery<Package> typed = session.createQuery(cq);
		
		typed.executeUpdate();
		
		
	}

	public Package getPackage(String ConsignmnetId) {
		Session currentSession=sessionFactory.getCurrentSession();
		Package thePackage=currentSession.get(Package.class, ConsignmnetId);
		return thePackage;
	}

	public List<Package> getPackageByUserId(String cutomerId) {
		
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<Package> cq=cb.createQuery(Package.class);
		Root<Package> root=cq.from(Package.class);
		cq.select(root);
		cq.where(cb.equal(root.get("customerId"),cutomerId));
		
		Query query=session.createQuery(cq);
		return query.getResultList();
	}
	

	public void updateDeliveryStatus(int consignmentId,String status) {
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<Package> cq=cb.createCriteriaUpdate(Package.class);
		
		Root<Package> e = cq.from(Package.class);
		
		
		cq.set("packagestatus",status);
		cq.where(cb.equal(e.get("id"), consignmentId));
		
		
		TypedQuery<Package> typed = session.createQuery(cq);
		
		typed.executeUpdate();
		
	}
	
	
	
}
