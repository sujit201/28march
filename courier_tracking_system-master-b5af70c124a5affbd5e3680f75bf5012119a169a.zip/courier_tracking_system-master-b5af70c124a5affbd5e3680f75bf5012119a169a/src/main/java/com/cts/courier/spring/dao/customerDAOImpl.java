package com.cts.courier.spring.dao;

import java.util.List;
import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.courier.spring.model.customer;
@Repository("customerDAO")
public class customerDAOImpl implements customerDAO{
	
	@Autowired
	SessionFactory sessionFactory;
	
	public List<customer> getCustomers() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<customer> cq=cb.createQuery(customer.class);
		Root<customer> root=cq.from(customer.class);
		cq.select(root);
		Query query=session.createQuery(cq);
		return query.getResultList();
	}
	
	@Transactional
	public void saveCustomer(customer theCustomer) {
		// TODO Auto-generated method stub
		Session currentSession=sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theCustomer);
	}

	@Transactional
	public customer getCustomer(int theId) {
		// TODO Auto-generated method stub
		Session currentSession=sessionFactory.getCurrentSession();
		customer theCustomer=currentSession.get(customer.class,theId);
		
		return theCustomer;
	}

	@Transactional
	public void deleteCustomer(int theId) {
		// TODO Auto-generated method stub
		Session currentSession=sessionFactory.getCurrentSession();
		customer book=currentSession.byId(customer.class).load(theId);
		currentSession.delete(book);
		customer theCustomer=currentSession.get(customer.class,theId);
		
	}
	
	@Transactional
	public customer verify(String username, String password) {
	
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<customer> cq=cb.createQuery(customer.class);
		
		Root<customer> root = cq.from(customer.class);
		cq.select(root);
		cq.where(cb.equal(root.get("username"),username),(cb.equal(root.get("pwd"),password)));
		
		TypedQuery<customer> typed = session.createQuery(cq);
		
		try {
			return typed.getSingleResult();
		}catch(Exception e) {
			
			System.out.println("in catch");
			return null;
		}
		
		
	}
	
}
