package com.cts.courier.spring.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.courier.spring.model.admin;
import com.cts.courier.spring.model.customer;

@Repository("adminDAO")
public class adminDAOImpl implements adminDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public List<admin> getCustomers() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<admin> cq=cb.createQuery(admin.class);
		Root<admin> root=cq.from(admin.class);
		cq.select(root);
		Query query=session.createQuery(cq);
		return query.getResultList();
	}
	
	@Transactional
	public void saveCustomer(admin theAdmin) {
		// TODO Auto-generated method stub
		Session currentSession=sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theAdmin);
	}

	public admin getCustomer(int theId) {
		Session currentSession=sessionFactory.getCurrentSession();
		admin theAdmin=currentSession.get(admin.class, theId);
		return theAdmin;
	}

	@Transactional
	public admin verify(String username, String pass) {
		Session session=sessionFactory.getCurrentSession();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaQuery<admin> cq=cb.createQuery(admin.class);
		
		Root<admin> root = cq.from(admin.class);
		cq.select(root);
		cq.where(cb.equal(root.get("username"),username),(cb.equal(root.get("password"),pass)));
		
		TypedQuery<admin> typed = session.createQuery(cq);
		
		try {
			return typed.getSingleResult();
		}catch(Exception e) {
			
			System.out.println("in catch");
			return null;
		}
		
		
	}
	
	
	
	
	
}
