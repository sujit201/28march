package com.cts.courier.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Package")
public class Package {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Id")
	int id;
	@Column(name="consignment_Id")
	String consignmentId;
	@Column(name="Date")
	String date;
	@Column(name="employee_Id")
	String employeeId;
	@Column(name="customer_Id")
	String customerId;
	@Column(name="sender_location")
	String senderlocation;
	@Column(name="Destination")
	String destination;
	@Column(name="weight")
	float weight;
	@Column(name="cost")
	float cost;
	@Column(name="package_status")
	String packagestatus;
	
	@Column(name="current_loaction")
	String current_location;
	
	public String getCurrent_location() {
		return current_location;
	}
	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}
	@Override
	public String toString() {
		return "Package [id=" + id + ", consignmentId=" + consignmentId + ", date=" + date + ", employeeId="
				+ employeeId + ", customerId=" + customerId + ", senderlocation=" + senderlocation + ", destination="
				+ destination + ", weight=" + weight + ", cost=" + cost + ", packagestatus=" + packagestatus + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getConsignmentId() {
		return consignmentId;
	}
	public void setConsignmentId(String consignmentId) {
		this.consignmentId = consignmentId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getSenderlocation() {
		return senderlocation;
	}
	public void setSenderlocation(String senderlocation) {
		this.senderlocation = senderlocation;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public String getPackagestatus() {
		return packagestatus;
	}
	public void setPackagestatus(String packagestatus) {
		this.packagestatus = packagestatus;
	}

}
