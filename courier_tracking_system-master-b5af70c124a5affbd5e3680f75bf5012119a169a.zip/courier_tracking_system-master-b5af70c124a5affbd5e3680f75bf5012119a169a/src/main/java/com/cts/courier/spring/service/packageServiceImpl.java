package com.cts.courier.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.courier.spring.dao.packageDAO;
import com.cts.courier.spring.model.Package;

@Service("packageservice")
public class packageServiceImpl implements packageservice {

	@Autowired
    packageDAO c;
    @Transactional
    public List<Package> getCustomers() {
           // TODO Auto-generated method stub
           return c.getCustomers();
    }
    @Transactional
    public void saveCustomer(Package thePackage) {
           // TODO Auto-generated method stub
           c.saveCustomer(thePackage);
    }
    @Transactional
    public Package getCustomer(int theId) {
           // TODO Auto-generated method stub
           return c.getCustomer(theId);
    }
    
    @Transactional
	public void updateCurrentLocation(int consignmentId,String date,String current_location) {
			c.updateCurrentLocation(consignmentId, date, current_location);
	}
    
    @Transactional
	public Package getPackage(String ConsignmnetId) {
		return c.getPackage(ConsignmnetId);
	}
    
    @Transactional
	public List<Package> getPackageByUserId(String cutomerId) {
		
		return c.getPackageByUserId(cutomerId);
	}
    
    @Transactional
	public void updateDeliveryStatus(int consignmentId, String status) {
		c.updateDeliveryStatus(consignmentId, status);
		
	}
}
