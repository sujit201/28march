-- MySQL dump 10.13  Distrib 5.6.13, for Win64 (x86_64)
--
-- Host: localhost    Database: courier
-- ------------------------------------------------------
-- Server version	5.6.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `courier`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `courier` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `courier`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Correspondence_Address` varchar(255) DEFAULT NULL,
  `Designation` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `Login_Type` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `Permanent_Address` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'ss','ss','ss','ss','male','ss','S','ss','ss','ss','ss','ss'),(2,'aa','aa','aa','aa','male','aa','A','aa','aa','aa','aa','aa'),(3,'','','','','male','','','','','','',''),(4,'','','','','male','','','','','','',''),(5,'dd','xcd','shalini@gmail.com','shalini','female','priya','A','shalini','dd','9174149042','223345566','shalini'),(6,'dd','dd','sd','sh','female','sf','S','sh','dd','2344','234544','sh'),(7,'asdd','asd','sujeet@gamil.com','sujeet','male','maity','S','sujeet','asdas','415678','458','sujeet'),(9,'Bhopal','Trainee','sujeet@gmail.com','sujeet','male','maity','A','sujeet','Bhopal','8269049201','10800','1412'),(10,'kolar','Trainee','sujeetmaity@gmail.com','sujeet','male','maity','A','sujeet','kolar','8269049201','10800','1214'),(11,'kolar','Trainee','sujeet@gmail.com','sujeet','male','maity','A','sujeet14','kolar','8269049201','10800','sujeet'),(12,'bhopal','Trainee','kevin@gmail.com','kevin','male','mathew','S','kevin','bhopal','1234567890','10800','kevin'),(13,'bhopal','Trainee','saksheet@gmail.com','saksheet','male','maity','S','saksheet','bhopal','1234567890','10800','saksheet'),(14,'bhopal','Trainee','saksheet@gmail.com','saksheet','male','maity','S','saksheet','bhopal','1234567890','10800','saksheet'),(15,'dsf','sdf','dsf','fsd','male','sdfsd','S','sd','dsf','4','ds','dsfsd'),(16,'bhopal','Trainee','sujeetmaity@gmail.com','sujit','male','maity','S','sujeet20','bhopal','1234567890','10800','sujeet20'),(17,'haryana','Trainee','mukul@gmail.com','mukul','male','manchanda','S','mukul','haryana','1234567890','10800','mukul'),(18,'kolar','Trainee','poornima@gmail.com','poornima','female','singh','S','poornima420','kolar','420','10800','poornima'),(19,'a','a','a','a','male','a','S','a','a','a','a','a'),(20,'gggg','ffgfg','abc@mail.','surbhi','female','sharma','S','123','gggg','12356','23445','surbhi');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (4,'sujeet@gmail.com','sujeet','male','maity','8269049201',NULL,'sujeet','sujeet14'),(5,'sujeetmaity26@gmail.com','sujeet','male','maity','8269049201',NULL,'sujeet','sujeet14'),(6,'sujeet','1233654','male','','',NULL,'',''),(7,'sujeet','','male','','',NULL,'',''),(8,'sujeet','','male','','',NULL,'',''),(9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'','','male','','',NULL,'',''),(13,'','','male','','',NULL,'',''),(14,'','','male','','',NULL,'',''),(15,'','','male','','',NULL,'',''),(16,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'','','male','','',NULL,'',''),(19,'','','male','','',NULL,'',''),(20,'','','male','','',NULL,'',''),(21,'abc@gmail.com','shalini','female','shalini','123',NULL,'shalini','shalini'),(22,'','','male','','',NULL,'',''),(23,'','','male','','',NULL,'',''),(24,'','','male','','',NULL,'',''),(25,'','','male','','',NULL,'',''),(26,'','','male','','',NULL,'',''),(27,'','','male','','',NULL,'',''),(28,'','','male','','',NULL,'',''),(29,'','','male','','',NULL,'',''),(30,'','','male','','',NULL,'',''),(31,'','','male','','',NULL,'',''),(32,'','','male','','',NULL,'',''),(33,'kevin@gmail.com','kevin','male','mathew','1234567890',NULL,'123456','kevin');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package`
--

DROP TABLE IF EXISTS `package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `consignment_Id` varchar(255) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `customer_Id` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Destination` varchar(255) DEFAULT NULL,
  `employee_Id` varchar(255) DEFAULT NULL,
  `package_status` varchar(255) DEFAULT NULL,
  `sender_location` varchar(255) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `current_loaction` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package`
--

LOCK TABLES `package` WRITE;
/*!40000 ALTER TABLE `package` DISABLE KEYS */;
INSERT INTO `package` VALUES (1,'fgdf',2.9,'gdfg','01/02/2019','gfdfg','fdfgdf','gfdfg','fdgfdg',2.5,'delhi'),(2,'dsad',2.5,'sdad','01/05/2018','sada','sdfs','dsadsad','dsasd',2.2,'pune'),(3,'sadasd',0,'dasdasd','10/02/2013','asdas','sdada','delivery','asd',0,'kokta'),(4,'adsad',0,'adasd','01/02/2001','adasd','asdsd','not delivered','adas',0,'kolar'),(5,'123',445,'ss','10/05/2000','mumbai','asdf','delivered','delhi',54,'kolar'),(6,'12',666.6,'ss','09/11/2019','kashmir','234','delivered','surat',50.6,'goa'),(7,'7',20.5,'456','10/02/2011','bhopal','123','delivered','surat',2.3,'goa'),(8,'8',50.2,'456','10/08/2016','gujrat','123','delivered','bhopal',1.1,'harda');
/*!40000 ALTER TABLE `package` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29 12:53:04
